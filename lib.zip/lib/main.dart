import 'package:background_location_poc/app.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}
